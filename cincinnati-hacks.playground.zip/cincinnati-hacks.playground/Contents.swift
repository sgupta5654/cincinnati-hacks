//This playground is for pasting in any helpful code/tibits. Design tips should be commented with double slashes. Totally independent and working code should be uploaded to GitHub in an xcodeproj format. Any code that you reuse can be pasted here for reference. Paste under your name. Any projects you guys work on this week can be posted on the repo so I know what you guys have been working on.

//Avi



//Ritvik




//Saransh





